#ifndef DATE_UTILS_H
#define DATE_UTILS_H

#include "Date.h"

// Утилиты для работы с датами
int subtractDates(const Date& lhs, const Date& rhs);

#endif
